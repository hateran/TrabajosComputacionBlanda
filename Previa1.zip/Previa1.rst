
.. code:: ipython3

    import numpy as np
    data = np.genfromtxt("DatosChina.csv", delimiter=";")
    
    # Se establece el tipo de dato
    data = np.array(data, dtype=np.int32)
    print(data)


.. parsed-literal::

    [[ 1  1]
     [ 2  2]
     [ 3  3]
     [ 4  1]
     [ 5  2]
     [ 6  2]
     [ 7  1]
     [ 8  1]
     [ 9 14]
     [10 17]
     [11  1]
     [12  7]
     [13  3]
     [14  4]
     [15  8]
     [16  6]
     [17  7]
     [18  6]
     [19  5]
     [20  2]
     [21  4]
     [22  0]
     [23  3]
     [24 11]
     [25  7]
     [26  1]
     [27  2]
     [28  0]
     [29  4]
     [30  2]
     [31 16]]


.. code:: ipython3

    # Se divide el array en dos vectores columnas: x, y
    
    # --------------------------------------------------------------
    x = data[:,0]
    y = data[:,1]
    # Se muestran los valores en x, y
    # --------------------------------------------------------------
    print(x, '\n')
    print(y, '\n')


.. parsed-literal::

    [ 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
     25 26 27 28 29 30 31] 
    
    [ 1  2  3  1  2  2  1  1 14 17  1  7  3  4  8  6  7  6  5  2  4  0  3 11
      7  1  2  0  4  2 16] 
    


.. code:: ipython3

    # Se importa la librería para graficar
    
    # --------------------------------------------------------------
    import matplotlib.pyplot as plt
    # Se dibuja, de manera abstracta, el punto (x,y)
    # con círculos de tamaño 10
    # --------------------------------------------------------------
    plt.scatter(x, y, s=10)
    # Títulos del gráfico
    # --------------------------------------------------------------
    plt.title("Datos covid-19 Mayo China")
    plt.xlabel("Dias")
    plt.ylabel("Casos nuevos")
    # --------------------------------------------------------------
    plt.autoscale(tight=True)
    # dibuja una cuadrícula punteada ligeramente opaca
    # --------------------------------------------------------------
    plt.grid(True, linestyle='-', color='0.75')



.. image:: output_2_0.png


